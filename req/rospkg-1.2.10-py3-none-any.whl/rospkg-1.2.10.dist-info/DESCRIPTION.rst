Library for retrieving information about ROS packages and stacks.


